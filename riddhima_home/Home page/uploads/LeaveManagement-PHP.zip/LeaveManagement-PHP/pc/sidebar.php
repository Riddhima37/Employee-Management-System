<div id="side_bar">
  	<ul>
    	<li class="menu_head">Control Panel</li>
        <li class="<?php if ($page == "view_leave_request") { echo 'activec';}?>"><a href="view_leave_requests.php">View Leave Request</a></li>
        <li class="<?php if ($page == "view_leave_history") { echo 'activec';}?>"><a href="search_staff_to_view_history.php">View Leave History</a></li>
    </ul>
  </div>