<div id="side_bar">
  	<ul>
    	<li class="menu_head">Control Panel</li>
        <li class="<?php if ($page == "apply_leave") { echo 'activec';}?>"><a href="apply_leave.php">Apply Leave</a></li>
        <li class="<?php if ($page == "view_leave_history") { echo 'activec';}?>"><a href="view_leave_history.php">View Leave History</a></li>
        <li class="<?php if ($page == "view_leave_status") { echo 'activec';}?>"><a href="view_leave_status.php">View Leave Status</a></li>
        <li class="<?php if ($page == "view_profile") { echo 'activec';}?>"><a href="view_profile.php">View Profile</a></li>
    </ul>
  </div>