<?php
	$conn = new mysqli('localhost', 'root', '', 'db_delete_upload');
	
	if(!$conn){
		die("Error: Failed to connect to database");
	}
?>